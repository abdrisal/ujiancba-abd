<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login | Sistem Informasi Aset</title>

    <!-- Style dipanggil dari file terpisah -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <main class="auth-card">

        <h2 class="judul">Login</h2>


        <!-- Tempat pesan error (isi dari PHP saat login gagal) -->
        <!-- <p class="auth-alert" role="alert">Email atau password salah.</p> -->

        <form action="proses_login.php" method="post" class="auth-form">

            <label for="email" class="sr-only">E-mail</label>
            <input
                type="email"
                id="email"
                name="email"
                class="auth-input"
                placeholder="E-mail"
                autocomplete="email"
                required
                autofocus>

            <label for="password" class="sr-only">Password</label>
            <input
                type="password"
                id="password"
                name="password"
                class="auth-input"
                placeholder="Password"
                autocomplete="current-password"
                required>

            <button type="submit" class="auth-button">Login</button>
        </form>

        <p class="auth-footer">
            Belum mempunyai akses? <a href="register.php">Register</a>
        </p>

    </main>

</body>

</html>