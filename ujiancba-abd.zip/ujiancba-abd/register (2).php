<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register | Sistem Informasi Aset</title>

    <!-- Style dipanggil dari file terpisah -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <main class="auth-card">

        <h2 class="judul">Register</h2>

        <!-- Tempat pesan error (isi dari PHP saat register gagal) -->
        <!-- <p class="auth-alert" role="alert">Username sudah dipakai.</p> -->

        <form action="proses_register.php" method="post" class="auth-form">

            <label for="username" class="sr-only">Username</label>
            <input
                type="text"
                id="username"
                name="username"
                class="auth-input"
                placeholder="Username"
                autocomplete="username"
                maxlength="50"
                required
                autofocus>

            <label for="email" class="sr-only">E-mail</label>
            <input
                type="email"
                id="email"
                name="email"
                class="auth-input"
                placeholder="E-mail"
                autocomplete="email"
                maxlength="100"
                required>

            <label for="password" class="sr-only">Password</label>
            <input
                type="password"
                id="password"
                name="password"
                class="auth-input"
                placeholder="Password"
                autocomplete="new-password"
                minlength="8"
                required>

            <label for="role" class="sr-only">Role</label>
            <select id="role" name="role" class="auth-input auth-select" required>
                <option value="" disabled selected>Role</option>
                <option value="admin">Admin</option>
                <option value="user">User</option>
            </select>

            <button type="submit" class="auth-button">Register</button>
        </form>

        <p class="auth-footer">
            Telah mempunyai akses? <a href="index.php">Login</a>
        </p>

    </main>

</body>

</html>